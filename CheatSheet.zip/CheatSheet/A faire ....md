https://openclassrooms.com/fr/courses/7274161-administrez-un-systeme-linux : LINUX

https://openclassrooms.com/fr/courses/2356316-montez-un-serveur-de-fichiers-sous-linux : LINUX

https://openclassrooms.com/fr/courses/1733551-gerez-votre-serveur-linux-et-ses-services : LINUX

https://openclassrooms.com/fr/courses/7727176-realisez-un-test-dintrusion-web/7915315-decouvrez-le-principe-d-un-test-d-intrusion : FAIRE UN TEST D'INTRUSION

https://www.youtube.com/watch?v=HVN4qv6Dxdk&list=PLrSOXFDHBtfEiSgOG1FM4oq-yS24iV4s1 : PYTHON EXO

https://www.youtube.com/watch?v=2R-BveCE-so&list=PLrSOXFDHBtfFMB2Qeuej6efzZRvjRdXo8 : PYTHON TUTO DOMAINE 

https://www.youtube.com/watch?v=HWxBtxPBCAc&list=PLrSOXFDHBtfHg8fWBd7sKPxEmahwyVBkC : PYTHON COURS

https://www.youtube.com/watch?v=f3UVQPbw32w&list=PLrSOXFDHBtfFKOzlm5iCBeXDTLxXdmxpx : C++  COURS

https://www.youtube.com/watch?v=py1E14pXfAM&list=PLrSOXFDHBtfHKxuz6NySItyf4iSEcTw97 : (FACULTATIF) LINUX COURS VIDEO

https://www.pierre-giraud.com/http-reseau-securite-cours : HTTP (sécurité et fonctionnement) COURS

https://www.youtube.com/watch?v=7lMXMLeawug&list=PLrSOXFDHBtfFuZttC17M-jNpKnzUL5Adc : PHP COURS 

https://www.youtube.com/watch?v=3KwmNNucIjA&list=PLrSOXFDHBtfGl66sXijiN8SU9YJaM_EQg : SQL COURS

https://www.youtube.com/watch?v=3KwmNNucIjA&list=PLrSOXFDHBtfGl66sXijiN8SU9YJaM_EQg : JAVA COURS