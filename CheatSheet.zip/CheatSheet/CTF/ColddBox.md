IP = 10.10.113.6

nmap_scan {
PORT   STATE SERVICE VERSION
80/tcp open  http    Apache httpd 2.4.18 ((Ubuntu))
|_http-server-header: Apache/2.4.18 (Ubuntu)
|_http-generator: WordPress 4.1.31
|_http-title: ColddBox | One more machine
MAC Address: 02:C9:88:74:1B:7B (Unknown)
Device type: general purpose
Running: Linux 3.X
OS CPE: cpe:/o:linux:linux_kernel:3
OS details: Linux 3.10 - 3.13
Network Distance: 1 hop
}
+
{
4512/tcp open  ssh     OpenSSH 7.2p2 Ubuntu 4ubuntu2.10 (Ubuntu Linux; protocol 2.0)
| ssh-hostkey: 
|   2048 4ebf98c09bc536808c96e8969565973b (RSA)
|   256 8817f1a844f7f8062fd34f733298c7c5 (ECDSA)
|_  256 f2fc6c750820b1b2512d94d694d7514f (ED25519)
}

gobuster {
/.htaccess            (Status: 403) [Size: 276]
/.htpasswd            (Status: 403) [Size: 276]
/hidden               (Status: 301) [Size: 311] [--> http://10.10.113.6/hidden/]
/server-status        (Status: 403) [Size: 276]
/wp-admin             (Status: 301) [Size: 313] [--> http://10.10.113.6/wp-admin/]
/wp-content           (Status: 301) [Size: 315] [--> http://10.10.113.6/wp-content/]
/wp-includes          (Status: 301) [Size: 316] [--> http://10.10.113.6/wp-includes/]
}