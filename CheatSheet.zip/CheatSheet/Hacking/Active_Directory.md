utiliser kerbrute :

[https://github.com/ropnop/kerbrute/releases](https://github.com/ropnop/kerbrute/releases)