SRC = Source 
DST = Destination 
TCP/IP = transsmission control protocole/ Internet protocol , c'est un protocole qui permet au ordinateur de communiqué avec un réseau comme internet 
4 couche dans le modele tcp ip :
#### Couche de liaison de données

La couche de liaison de données, également appelée couche d'interface réseau ou couche physique, gère les parties physiques de l'envoi et de la réception de données à l'aide du câble Ethernet, du réseau sans fil, de la carte d'interface réseau, du pilote de périphérique de l'ordinateur, etc.

#### Couche Internet

La couche Internet, également appelée couche réseau, contrôle le mouvement des paquets sur le réseau.

#### Couche transport

La couche transport fournit une connexion des données fiable entre deux appareils. Elle divise les données en paquets, accuse réception des paquets qu'elle a reçus de l'autre appareil et s'assure que ce dernier accuse réception des paquets qu'il reçoit.

#### Couche application

La couche application est le groupe d'applications nécessitant une communication réseau. Il s'agit généralement de l'application avec laquelle l'utilisateur interagit, comme les e-mails et la messagerie. Parce que les couches inférieures gèrent les détails de la communication, les applications n'ont pas besoin de s'en préoccuper.
