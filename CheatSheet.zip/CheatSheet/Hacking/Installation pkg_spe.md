
1er installer impacket 

git clone https://github.com/SecureAuthCorp/impacket.git /opt/impacket

pip3 install -r /opt/impacket/requirements.txt

cd /opt/impacket/ && python3 ./setup.py install

pour attaquer l'active directory installer : 

apt install bloodhound neo4j

apt update && apt upgrade
