scan de port :

nmap -Ss <IP>

Scan Automatique :

nmap -A -v <IP>

SMB énumération :

enum4linux [opion] <IP>

connexion telnet :

telnet [ip] [port]

NFS [network file system] énumeration : apt install nfs-common Lister les partage :

/usr/sbin/showmount -e [IP]

NFS connexion

mount -t nfs <IP>:[nom_du_partage] /mnt -nolock

mount -o rw,vers=3 <IP>:<chemin du partage> <ou le monter sur ma machine>

Mysql téléchargement :

apt install default-mysql-client

enuméré smb :

nmap -p 445 --script=smb-enum-shares.nse,smb-enum-users.nse <IP>

énumération de NFS  :

nmap -p <PORT> --script=nfs-ls,nfs-statfs,nfs-showmount <IP>

NMAP : : : 

Analyse ARP :	sudo nmap -PR -sn MACHINE_IP/24

Analyse d'écho ICMP :	sudo nmap -PE -sn MACHINE_IP/24

Scan d'horodatage ICMP :	sudo nmap -PP -sn MACHINE_IP/24

Analyse du masque d'adresse ICMP :	sudo nmap -PM -sn MACHINE_IP/24

Balayage TCP SYN Ping : 	sudo nmap -PS22,80,443 -sn MACHINE_IP/30

Balayage TCP ACK : 	sudo nmap -PA22,80,443 -sn MACHINE_IP/30

Analyse de ping UDP : 	sudo nmap -PU53,161,162 -sn MACHINE_IP/30

nmap -sn si uniquement interesse par les hotes sans les ports

WIRESHARK FILTRE :
	-   et - opérateur : and / &&
	-   ou - opérateur : or / ||
	-   égal - opérateur :  eq / ==
	-   pas égal - opérateur :  ne / !=
	-   supérieur à - opérateur : gt /  >
	-   inférieur à - opérateur : lt / <
>
ip.addr == <IP Address>       :   pour spécifier qu'il faut trouver des packets avec cette ip
ip.src == <SRC IP Address> and ip.dst == <DST IP Address>  :  va voir dans cours protocole ett le reste pour capter SRC DST
tcp.port eq <Port #> or <Protocol Name> :filtre pour trouver les packets port et protocole , c'est la meme pour udp saufe qu'on remplace tcp par udp