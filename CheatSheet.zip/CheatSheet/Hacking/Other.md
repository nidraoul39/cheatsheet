visionner les services activer sur linux :

service --status-all

firewall sous linux :

apt install ufw : CLI (command line interface)

[https://github.com/costales/gufw](https://github.com/costales/gufw) : interface grafique de ufw

alternative à apt :

apt install nala

stabilisation de shell netcat :

python3 -c 'import pty;pty.spawn("/bin/bash")' : utilise python pour un shell plus complet

export TERM=xterm : pour nous donner acces a des commande comme clear

puis passez le shell nc en arriere plan CTRL + Z puis : stty raw -echo; fg : pour utiliser des commande comme CTRL + C

extention utile au pentest web :

foxyproxy pour changer de proxy en un clique 

user-agent switcher and manager pour faire croire que l'on visite un site depuis un autre os

Wappalyzer fournis des information sur les technologie utiliser par le site

netcat et telnet tres utile pour connexion au service en tcp / udp syntax:

nc <IP> <PORT>

telnet <IP> <PORT>

de plus netcat peux etre utiliser comme server avec :

nc -lnvp <PORT>

