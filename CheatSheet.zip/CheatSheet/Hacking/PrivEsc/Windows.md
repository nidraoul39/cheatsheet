utilisation de script comme winPEAS pour énumérer l'élévation de privilège Windows :

Trouver les services actif depuis powershell :

Powershell -c Get-Service