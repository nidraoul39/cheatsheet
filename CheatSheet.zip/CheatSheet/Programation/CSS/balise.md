Sélecteur CSS

Signification

`*`

Sélectionne tous les éléments

`E, F`

Sélectionne tous les éléments de type E et de type F

`E F`

Sélectionne tous les éléments F à l’intérieur des éléments E

`E > F`

Sélectionne les éléments F enfants directs des éléments E

`E + F`

Sélectionne tout élément F placé directement après un élément E

`E~F`

Sélectionne tout élément F placé après un élément E dans la page

