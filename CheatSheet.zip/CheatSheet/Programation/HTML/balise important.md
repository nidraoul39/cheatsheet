<link> pour lier au css

<table></table> faire un tableau
<caption></caption> donner un titre au tableau
<tr></tr> colone du tableau
<th></th> titre des colone 
<td></td>contenu du tableau

<from action="fichier php de recuperation de la requete" method="requete (get, post, put ,delte)"></from>
<label for="nom du champ">nom du champ</label> info pour savoir quoi entrer
<input type="text, password,email, <type a utiliser pour envoyer = submit>" name="info a entrer" id="nom du champ"> pour pouvoir entrer et etre lier au label
dans input utiliser <placeholder="votre mdp, email ..."> pour montrer quoi entrer

