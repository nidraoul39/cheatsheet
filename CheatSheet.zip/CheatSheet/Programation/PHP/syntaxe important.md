
crée une variable 
$nom_de_la_variable = <contenue>

récuperer du code php depuis in fichier et l'inclure
<?php include 'fichier.php' ?>

-   La boucle `while` (« tant que ») ;
	while($x >= 8){           }
-   La boucle `do… while` (« faire… tant que ») ;
-   La boucle `for` (« pour ») ;
-   La boucle `foreach` (« pour chaque ») ;

utilisation de switch pour vérifier des cas particulier exemple : 

$x = 2

switch($x){
case 0 :
	echo "c egal a 0";
	break ;
case 1 :
	echo "c egal a 1";
	break ;
case 2 :
	echo "c egal a 2";
	break ;
case 3 :
	echo "c egal a 3";
	break ;
case 4 :
	echo "c egal a 4";
	break ;
default :
	echo "c pas entre 0 et 4"
}
 



isset($_POST['formsend']) ;
permet de vérifier si l'element est reçu 

if(!empty($variable));
si la variable est pas null

pour relier la base de donné a un fichier php :

    define('HOST' , '<addresse ip ou localhost si heberger sur le mm server>')
    define('DB_NAME','<nom de la base de donné>')
    define('USER','<utilisateur>')
    define('PASS', '<Mot de passe>')


puis : : :
    try <essaie>{
        $db = new PDO("mysql:host=" . HOST . ";dbname=" . DB_NAME, USER, PASS);
        $db->setAttribute<presise les erreur>(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        echo "Connexion > OK !";
    } catch(PDOException <si erreur renvoie l erreur> $e) {
        echo $e; <si erreur renvoie l erreur>
    }


utilisation de variable d'un autre fichier apres avoir fais include :

global $variable ;

extract($_POST); 
pour transformer toute les requete en variable directement

rowcount() permet de compter le nb de resultat dans une requete sql

$q->fetch(); 
c'est pour recuperer le resultat d'une requete
puis
var_dump($result);
pour l'afficher


<select name="nom" id="nom" require>
      <option value="">categorie de choix</option>
       <option value="nom d'un choix">nom d'un choix</option>
       <option value="nom d'un choix">nom d'un choix</option>
</select> <br><br>