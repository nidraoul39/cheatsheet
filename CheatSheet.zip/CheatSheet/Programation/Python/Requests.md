import requests
Exemple de récuperation du HTML d'une page
[
url = "https://www.example.com"

response = requests.get(url)
print(response.text)
]

Ou envoyer des donner (requête POST)
[

data= {"username": "john", "email": "bg@gmail .com"}
response = requests.post(url, data=data) print(response.text)
]
