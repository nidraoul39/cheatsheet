Sélecteur CSS:
Signification

`*`      Sélectionne tous les éléments

`E, F`    Sélectionne tous les éléments de type E et de type F

`E F`      Sélectionne tous les éléments F à l’intérieur des éléments E

`E > F`   Sélectionne les éléments F enfants directs des éléments E

`E + F`     Sélectionne tout élément F placé directement après un élément E

`E~F`      Sélectionne tout élément F placé après un élément E dans la page


utilisation de display flex ; 
 utile :
	 flex-direction
	 space-around
 autoriser les elements d'un block a aller a la ligne avec : 
	 flex-wrap

aussi autre  : 
	-   `stretch`  (par défaut) : les éléments s'étirent pour occuper tout l'espace ;
    
	   `flex-start`  : les éléments sont placés au début ;
    
	   `flex-end`  : les éléments sont placés à la fin ;
    
	   `center`  : les éléments sont placés au centre ;
    
	  `space-between`  : les éléments sont séparés avec de l'espace entre eux ;
    
	   `space-around`  : idem, mais il y a aussi de l'espace au début et à la fin.




diplay grid  :  pour faire des grille 

1.  `**grid-template-columns**` pour le nombre de colonnes, et la largeur de chacune d'entre elles.
    
2.  `**grid-template-rows**` pour le nombre de rangées, et la hauteur de chacune d'entre elles.

3.  `**gap**` pour l'espace entre chaque colon et grille 

utilisation de :: 

-   **`grid-column-start`** indique la ligne verticale de départ de l'élément ;
-   **`grid-column-end`** indique la ligne verticale d'arrivée de l'élément ;
-   **`grid-row-start`** indique la ligne horizontale de départ de l'élément ;
-   **`grid-row-end`** indique la ligne horizontale d'arrivée de l'élément;


pour  faire des bordure en css utiliser la propriété  : **`border : `**
rassemblé toute les cellule pour un tableau **`border-collapse: collapse`**
